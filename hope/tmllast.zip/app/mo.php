<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class mo extends Model
{
    protected $table = 'patient';
    //protected $fillable =['id', 'name' , 'email' , 'remember_token','created_at','updated_at'] ; 
}
